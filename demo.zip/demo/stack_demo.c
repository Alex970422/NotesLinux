#include <stdint.h>
#include <stdio.h>
#include <string.h>

struct frame_marker {
    uint32_t head;
    char label[12];
    uint32_t tail;
};

static void
fill_buffer(char *buf, size_t len, char fill)
{
    if (len == 0) {
        return;
    }

    memset(buf, fill, len - 1);
    buf[len - 1] = '\0';
}

static void
stack_probe(void)
{
    char ascii_buffer[16];
    char pattern_buffer[32];
    struct frame_marker marker = {
        .head = 0xDEADBEEF,
        .label = "STACK_DEMO",
        .tail = 0xCAFEBABE,
    };
    uint64_t ticket = 0x1337133713371337ULL;
    volatile uint64_t sentinel = 0xBADC0FFEE0DDF00DULL;

    fill_buffer(ascii_buffer, sizeof ascii_buffer, 'A');
    fill_buffer(pattern_buffer, sizeof pattern_buffer, 'B');

    printf("Inside stack_probe()\n");
    printf(" marker.head   = 0x%08X\n", marker.head);
    printf(" marker.label  = %s\n", marker.label);
    printf(" marker.tail   = 0x%08X\n", marker.tail);
    printf(" ticket        = 0x%016llX\n", (unsigned long long)ticket);
    printf(" sentinel      = 0x%016llX\n", (unsigned long long)sentinel);
    printf(" ascii_buffer  @ %p -> %s\n", (void *)ascii_buffer, ascii_buffer);
    printf(" pattern_buffer@ %p -> %s\n", (void *)pattern_buffer, pattern_buffer);
    puts("Break in GDB on stack_probe to inspect the stack frames.");
}

int
main(void)
{
    puts("=== Stack demo ready ===");
    stack_probe();
    puts("=== Done ===");
    return 0;
}
